class TreeNode
  attr_writer :parent

  def initialize(value = nil)
    @value = value
    @parent = nil
    @left_child = nil
    @right_child = nil
  end

  def parent
    @parent
  end

  # Setters
  def left=(left_child)
    disown_child(@left_child)
    @left_child = left_child
    left_child.parent = self
  end

  def right=(right_child)
    disown_child(@right_child)
    @right_child = right_child
    right_child.parent = self
  end

  def value=(value)
    @value = value
  end

  # Getters
  def left
    @left_child
  end

  def right
    @right_child
  end

  def value
    @value
  end

  private

  def to_s
    "Value: \t#{ @value.nil? ? 'nil' : value }\n" + \
    "Parent:\t#{ @parent.nil? ? 'nil' : @parent.value }\n" + \
    "Left: \t#{ @left_child.nil? ? 'nil' : @left_child.value }\n" + \
    "Right: \t#{ @right_child.nil? ? 'nil' : @right_child.value }\n"
  end

  def disown_child(child)
    child.parent = nil unless child.nil?
  end

end

if __FILE__ == $PROGRAM_NAME
  a = TreeNode.new('A')
  b = TreeNode.new('B')
  c = TreeNode.new('C')
  a.left = b
  p a
  # Value:   A
#   Parent:  nil
#   Left:   B
#   Right:   nil
  p b
  # Value:   B
#   Parent:  A
#   Left:   nil
#   Right:   nil
  a.left = c
  p a
  # Value:   A
#   Parent:  nil
#   Left:   C
#   Right:   nil
  p b
  # Value:   B
#   Parent:  nil
#   Left:   nil
#   Right:   nil
  p c
  # Value:   C
#   Parent:  A
#   Left:   nil
#   Right:   nil
end
