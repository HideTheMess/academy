var moveStuff = (function () {
	var array = []
	var fun = function(id) {
		array.push(id);
		if (array.length < 2) {
			return fun;
		}
		else {
			if(Hanoi.move_valid(Hanoi[array[0]], Hanoi[array[1]])){
				return Hanoi.move(Hanoi[array.shift()], Hanoi[array.shift()]);
			}else{
				alert(array.shift() + "can't go on" + array.shift())
			}
		}
	};
	return fun;
})();

var render = function () {
	$('body').empty();
	for (var i = 3; i >= 1; i--) {
		$('body').append('<div id="height' + i + '"><span id="tower1">'+
				(Hanoi.tower1[i-1] || '_') +' '+'</span>'+
				'<span id="tower2">'+ (Hanoi.tower2[i-1] || '_') +' '+'</span>'+
				'<span id="tower3">'+ (Hanoi.tower3[i-1] || '_' )+' '+'</span></div>');
	}
};

var begin = function () {
	render();
	if(Hanoi.won()){alert("Oh yeah!")}
	$('span').on('click', function(){
		$(this).toggleClass('highlight');
		moveStuff($(this).attr('id'));
		begin();
	})

};
$(begin);
