$(function(){
	var game = new TTT();
	var loop = function(){
		render(); //write this
		$(".empty").on('click', function(){
			$(this).toggleClass(".empty");
			game.placeMark($(this).attr('name')); // fix this
			if (game.winner()) {
				render();
				alert("Win!");
				location.reload();
			}
			game.switchPlayer();
			loop();
		})
	};
	var render = function(){
		$('body').empty();
		var addBoxes = function(row, i){
			var string = ""
			row.forEach(function(ele, j){
				string+=("<span name='"+i+j+"' class="+ (ele || "'empty'")+">"+
					(ele || "_ ")+"</span>")
			});
			$('body').append($("<div></div>").html(string));
		}
		game.board.forEach(addBoxes)
		console.log(game.board) //returns array of nils first
	}

	loop();

});